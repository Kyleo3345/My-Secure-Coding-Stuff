/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package m10.assignment.kyleo;

import java.io.*;
import java.net.*;

public class CalculatorServer {
    private static final int PORT = 9999;

    public static void main(String[] args) {
        CalculatorService calculatorService = new CalculatorServiceImpl();

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server started, waiting for connections...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                new Thread(new ClientHandler(clientSocket, calculatorService)).start();
            }
        } catch (IOException e) {
            System.err.println("Server exception: " + e.getMessage());
        }
    }
}

class ClientHandler implements Runnable {
    private final Socket clientSocket;
    private final CalculatorService calculatorService;

    public ClientHandler(Socket socket, CalculatorService service) {
        this.clientSocket = socket;
        this.calculatorService = service;
    }

    @Override
    public void run() {
        try (
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))
        ) {
            String inputLine, outputLine;
            while ((inputLine = in.readLine()) != null) {
                outputLine = processOperation(inputLine);
                out.println(outputLine);
            }
        } catch (IOException e) {
            System.err.println("Exception caught when trying to listen on port or listening for a connection");
            System.err.println(e.getMessage());
        }
    }

    private String processOperation(String input) {
        String[] tokens = input.split(" ");
        double result = 0;
        double firstValue = Double.parseDouble(tokens[0]);
        double secondValue = Double.parseDouble(tokens[2]);
        char operation = tokens[1].charAt(0);
        
        try {
            switch (operation) {
                case '+' -> result = calculatorService.add(firstValue, secondValue);
                case '-' -> result = calculatorService.sub(firstValue, secondValue);
                case '/' -> result = calculatorService.div(firstValue, secondValue);
                case '*' -> result = calculatorService.mul(firstValue, secondValue);
                default -> {
                    return "Error: Invalid operation.";
                }
            }
        } catch (ArithmeticException e) {
            return "Error: " + e.getMessage();
        }

        return String.valueOf(result);
    }
}


