/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package m10.assignment.kyleo;

import java.io.*;
import java.net.*;

/**
 *
 * @author angel
 */
public class CalculatorClient {
    private static final String HOST = "localhost";
    private static final int PORT = 12345;

    public static void main(String[] args) throws IOException {
        try (
            Socket socket = new Socket(HOST, PORT);
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in))
        ) {
            String userInput;
            System.out.println("Online Calculator");
            printMenu();

            while ((userInput = stdIn.readLine()) != null) {
                if ("5".equals(userInput)) {
                    System.out.println("Exiting...");
                    break;
                }
                try {
                    int option = Integer.parseInt(userInput);
                    handleMenuOption(option, stdIn, out);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input, please enter a number between 1-5.");
                    printMenu();
                    continue;
                }

                // Read and print the server's response
                System.out.println("Server says: " + in.readLine());
                printMenu();
            }
        } catch (UnknownHostException e) {
            System.err.println("Don't know about host " + HOST);
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Couldn't get I/O for the connection to " +
                HOST);
            System.exit(1);
        }
    }

    private static void printMenu() {
        System.out.println("\n1) Addition");
        System.out.println("2) Subtraction");
        System.out.println("3) Division");
        System.out.println("4) Multiplication");
        System.out.println("5) Exit");
        System.out.print("Choice: ");
    }

    private static void handleMenuOption(int option, BufferedReader stdIn, PrintWriter out) throws IOException {
        String firstNumber, secondNumber, operation = null;

        switch (option) {
            case 1 -> operation = "+";
            case 2 -> operation = "-";
            case 3 -> operation = "/";
            case 4 -> operation = "*";
            default -> {
                System.out.println("Invalid choice. Please try again."); return;
            }
        }

        System.out.print("Enter First Number: ");
        firstNumber = stdIn.readLine();
        System.out.print("Enter Second Number: ");
        secondNumber = stdIn.readLine();

        out.println(firstNumber + " " + operation + " " + secondNumber);
    }
}
