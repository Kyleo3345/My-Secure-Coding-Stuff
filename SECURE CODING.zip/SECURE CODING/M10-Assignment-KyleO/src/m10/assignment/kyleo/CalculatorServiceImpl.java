/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package m10.assignment.kyleo;

/**
 *
 * @author angel
 */
public class CalculatorServiceImpl implements CalculatorService {
    @Override
    public double add(double firstValue, double secondValue) {
        return firstValue + secondValue;
    }

    @Override
    public double sub(double firstValue, double secondValue) {
        return firstValue - secondValue;
    }

    @Override
    public double div(double firstValue, double secondValue) {
        if(secondValue == 0) throw new ArithmeticException("Division by zero.");
        return firstValue / secondValue;
    }

    @Override
    public double mul(double firstValue, double secondValue) {
        return firstValue * secondValue;
    }
}
