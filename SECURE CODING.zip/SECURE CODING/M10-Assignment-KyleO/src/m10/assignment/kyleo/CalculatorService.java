/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package m10.assignment.kyleo;

/**
 *
 * @author angel
 */
public interface CalculatorService {
     public double add(double firstValue, double secondValue);
     public double sub(double firstValue, double secondValue);
     public double div(double firstValue, double secondValue);
     public double mul(double firstValue, double secondValue);
 }
