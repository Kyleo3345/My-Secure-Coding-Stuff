/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package m8.assignment.kyleo;

import java.sql.*;

public class M8AssignmentKyleO {
    
    private final Connection conn;
    
    public M8AssignmentKyleO() throws SQLException {
           String databaseURL = "jdbc:ucanaccess://c://JDBC//TestDB.accdb";
           conn = DriverManager.getConnection(databaseURL);
        }
    
    public void createTable() throws SQLException {
        //String createStudentTableSQL = "CREATE TABLE Student (sid INTEGER, sname TEXT(50),major TEXT(30), email TEXT(50));";
        String createCourseTableSQL = "CREATE TABLE Course (cid TEXT(50), credits INTEGER, semester TEXT(20));";
        //PreparedStatement stmt1 = conn.prepareStatement(createStudentTableSQL);
            PreparedStatement stmt2 = conn.prepareStatement(createCourseTableSQL);
            //stmt1.executeUpdate();
            stmt2.executeUpdate();
        
    }
    
    public void insertCourses(String cid, int credits, String semester) throws SQLException {
        String insertCourseSQL1 = "INSERT INTO Course (cid, credits, semester) VALUES ('Math', 3, Fall);";
        String insertCourseSQL2 = "INSERT INTO Course (cid, credits, semester) VALUES ('Calculus', 4, Fall);";
        try (PreparedStatement stmt1 = conn.prepareStatement(insertCourseSQL1);) {
            stmt1.executeUpdate();
        }
        try (PreparedStatement stmt2 = conn.prepareStatement(insertCourseSQL2);) {
            stmt2.executeUpdate();
        }
    }
    
    public void insertStudents(int sid, String sname, String major, String email) throws SQLException {
        String insertStudentSQL = "INSERT INTO Student (sid, sname, major, email) VALUES (?, ?, ?, ?);";
        
        try (PreparedStatement stmt = conn.prepareStatement(insertStudentSQL)) {
            stmt.execute();
        }
    }
    
    public void updateData(String courseName, int newCredits) throws SQLException {
        String updateCourseSQL = "UPDATE Course SET credits = 5 WHERE cid = 'Calculus';";
        
        try (PreparedStatement stmt = conn.prepareStatement(updateCourseSQL)) {
            stmt.executeUpdate();
        }
    }
    
    public void selectCourse(String semester, int minCredit) throws SQLException {
        String selectCourseSQL = "SELECT * FROM Course WHERE semester = 'Fall' AND credits > 3;";
        
        try (PreparedStatement stmt = conn.prepareStatement(selectCourseSQL)) {
            stmt.execute();
        }
    }
    
    public void deleteStudent(String studentName) throws SQLException {
        String deleteStudentSQL = "DELETE FROM Student WHERE sname = '?';";
        
        try (PreparedStatement stmt = conn.prepareStatement(deleteStudentSQL)) {
            stmt.executeUpdate();
        }
    }
    
    public static void main(String[] args) throws SQLException {
        M8AssignmentKyleO m = new M8AssignmentKyleO();
        
        m.createTable();
    }
}
