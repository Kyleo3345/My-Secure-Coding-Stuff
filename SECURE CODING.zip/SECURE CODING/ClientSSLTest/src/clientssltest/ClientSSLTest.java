/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clientssltest;

import java.io.*;
import javax.net.ssl.*;

public class ClientSSLTest {

    public static void main(String[] args) throws IOException{
        
        System.setProperty("javax.net.ssl.keyStore", "C:\\Users\\angel\\Kosterman\\cacerts.store");
        System.setProperty("javax.net.ssl.keyStorePassword", "110354");
        System.setProperty("javax.net.debug", "ssl");

        SSLSocketFactory sslsocketfactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
        SSLSocket sslSocket = (SSLSocket) sslsocketfactory.createSocket("localhost", 9999);

        BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
        BufferedReader inFromServer = new BufferedReader(new InputStreamReader(sslSocket.getInputStream()));
        BufferedWriter outToServer = new BufferedWriter(new OutputStreamWriter(sslSocket.getOutputStream()));
        String string = null;
        while ((string = inFromUser.readLine()) != null) {
            outToServer.write(string + '\n');
            outToServer.flush();
            String modifiedSentence = inFromServer.readLine();
            System.out.println("\nReceived from server: " + modifiedSentence);
        }

        inFromUser.close();
        inFromServer.close();
        outToServer.close();
        sslSocket.close();

    }

}
