/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package project2.kyleo;

import java.util.*;

/**
 * Program: Cryptography 
 * This: Project2KyleO 
 * Author: Kyle Osterman 
 * Date: 11-April-2024
 */
public class Project2KyleO {

    //Matrix for the code
    public static char[][] matrix = {
        {'A', 'B', 'C', 'D', 'E'},
        {'F', 'G', 'H', 'I', 'J'},
        {'K', 'L', 'M', 'N', 'O'},
        {'P', 'Q', 'R', 'S', 'T'},
        {'U', 'V', 'W', 'X', 'Y'},};

    //Function to remove numbers and symbols
    public static String removeNumbersAndSymbols(String str) {
        return str.replaceAll("[^a-zA-Z ]", "").toUpperCase();
    }
    //Function to convert letters into 2-digit string

    public static String letterToDigits(char letter) {
        int row, col;
        switch (letter) {
            case 'A' -> {
                row = 0;
                col = 0;
            }
            case 'B' -> {
                row = 0;
                col = 1;
            }
            case 'C' -> {
                row = 0;
                col = 2;
            }
            case 'D' -> {
                row = 0;
                col = 3;
            }
            case 'E' -> {
                row = 0;
                col = 4;
            }
            case 'F' -> {
                row = 1;
                col = 0;
            }
            case 'G' -> {
                row = 1;
                col = 1;
            }
            case 'H' -> {
                row = 1;
                col = 2;
            }
            case 'I' -> {
                row = 1;
                col = 3;
            }
            case 'J' -> {
                row = 1;
                col = 4;
            }
            case 'K' -> {
                row = 2;
                col = 0;
            }
            case 'L' -> {
                row = 2;
                col = 1;
            }
            case 'M' -> {
                row = 2;
                col = 2;
            }
            case 'N' -> {
                row = 2;
                col = 3;
            }
            case 'O' -> {
                row = 2;
                col = 4;
            }
            case 'P' -> {
                row = 3;
                col = 0;
            }
            case 'Q' -> {
                row = 3;
                col = 1;
            }
            case 'R' -> {
                row = 3;
                col = 2;
            }
            case 'S' -> {
                row = 3;
                col = 3;
            }
            case 'T' -> {
                row = 3;
                col = 4;
            }
            case 'U' -> {
                row = 4;
                col = 0;
            }
            case 'V' -> {
                row = 4;
                col = 1;
            }
            case 'W' -> {
                row = 4;
                col = 2;
            }
            case 'X' -> {
                row = 4;
                col = 3;
            }
            case 'Y' -> {
                row = 4;
                col = 4;
            }
            case 'Z' -> {
                row = 3;
                col = 1;
            }
            default -> {
                row = 0;
                col = 0;
            }
        }

        return Integer.toString(row) + Integer.toString(col);
    }
    // Function to create the grid of digits for the keyword

    public static int[][] createKeywordGrid(String keyword, String message) {
        int rows = message.length() / keyword.length() + (message.length() % keyword.length() == 0 ? 0 : 1);
        int[][] grid = new int[rows][keyword.length()];
        int index = 0;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < keyword.length(); j++) {
                if (index < message.length()) {
                    grid[i][j] = Character.getNumericValue(message.charAt(index));
                    index++;
                }
            }
        }
        return grid;
    }
    
    // Function to sort the grid by alphabetical order of the keyword
    public static int[][] sortGrid(String keyword, int[][] grid) {
        int[][] sortedGrid = new int[grid.length][keyword.length()];
        char[] sortedKeyword = keyword.toCharArray();
        Arrays.sort(sortedKeyword);
        Map<Character, Integer> indexMap = new HashMap<>();
        for (int i = 0; i < keyword.length(); i++) {
            indexMap.put(sortedKeyword[i], i);
        }
        for (int i = 0; i < keyword.length(); i++) {
            int col = indexMap.get(keyword.charAt(i));
            for (int j = 0; j < grid.length; j++) {
                sortedGrid[j][i] = grid[j][col];
            }
        }
        return sortedGrid;
    }
    
    // Function to encrypt the message
    public static String encryptMessage(int[][] grid) {
        StringBuilder encryptedMessage = new StringBuilder();
        for (int[] grid1 : grid) {
            for (int j = 0; j < grid1.length; j++) {
                encryptedMessage.append(grid1[j]);
            }
        }
        return encryptedMessage.toString();
    }
    
    public static String sortString(String inputString)
    {
        // Converting input string to character array
        char tempArray[] = inputString.toCharArray();

        // Sorting temp array using
        Arrays.sort(tempArray);

        // Returning new sorted string
        return new String(tempArray);
    }
    
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        //Input the message you want to use
        System.out.println("Enter a message to encrypt:");
        String message = scan.nextLine();
        String processedMessage = removeNumbersAndSymbols(message);
        
        //Input the Keyword you want to use
        System.out.println("Enter a keyword for encryption (NO REPEAT CHARACTERS!):");
        String keyword = scan.nextLine().toUpperCase();
        
        // Convert message to numerical sequence
        System.out.println("Message to Be Encrypted: " + processedMessage);
        processedMessage = processedMessage.replaceAll("\\s", "");
        StringBuilder messageSequence = new StringBuilder();
        for (int i = 0; i < processedMessage.length(); i++) {
            char letter = processedMessage.charAt(i);
            messageSequence.append(letterToDigits(letter));
        }
        
        // Keyword Validation
        Set<Character> uniqueChars = new HashSet<>();
        for (char c : keyword.toCharArray()) {
            if (!Character.isLetter(c)) {
                System.out.println("Keyword should only contain letters. Please enter a valid keyword.");
                return;
            }
            if (uniqueChars.contains(c)) {
                System.out.println("Keyword should not contain duplicate characters. Please enter a valid keyword.");
                return;
            }
            uniqueChars.add(c);
        }

        // Create keyword grid and Sort grid by alphabetical order of the keyword
        int[][] keywordGrid = createKeywordGrid(keyword, messageSequence.toString());
        int[][] sortedGrid = sortGrid(keyword, keywordGrid);

        //Output
        System.out.println("Keyword: " + keyword);
        System.out.println("Keyword Matrix:");

        StringBuilder sb = new StringBuilder(keyword);
        for (int i = 1; i < sb.length(); i += 2) {
            sb.insert(i, ' ');
        }
        System.out.println(sb.toString());

        for (int[] keywordGrid1 : keywordGrid) {
            for (int j = 0; j < keywordGrid1.length; j++) {
                System.out.print(keywordGrid1[j] + " ");
            }
            System.out.println();
        }
        
        String inputString = keyword;
        String outputString = sortString(inputString);

        
        System.out.println("Alphabetical Keyword: " + outputString);
        System.out.println("Alpabetized Matrix:");
        
        StringBuilder st = new StringBuilder(outputString);
        for (int i = 1; i < st.length(); i += 2) {
            st.insert(i, ' ');
        }
        System.out.println(st.toString());
        
        for (int[] sortedGrid1 : sortedGrid) {
            for (int j = 0; j < sortedGrid1.length; j++) {
                System.out.print(sortedGrid1[j] + " ");
            }
            System.out.println();
        }
        
        System.out.println("Fully Encrypted Message: " + encryptMessage(sortedGrid));

    }
}
