/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dbconnection;

import java.sql.*;

public class DBConnection {
    
    public static void main(String[] args) {
        Connection conn = null;
        Statement statement = null;
        ResultSet resultSet = null;
        String databaseURL = "jdbc:ucanaccess://c://JBDC//TestDB.accdb";
        try
        {
            // Step 1: Establish Connection 
            conn = DriverManager.getConnection(databaseURL);  
            System.out.println("Connected Successfully");
              
            // Step 2: Creating JDBC Statement 
            statement = conn.createStatement();
 
            // Step 3: Executing SQL and retrieve data into ResultSet
            resultSet = statement.executeQuery("SELECT * FROM PLAYER");
            System.out.println("ID\tName\t\t\tAge\tMatches");
            System.out.println("==\t==================\t===\t=======");
 
            while(resultSet.next())
            {
                System.out.println(resultSet.getInt(1) + "\t" + 
                        resultSet.getString(2) + "\t" + 
                        resultSet.getInt(3) + "\t" +
                        resultSet.getInt(4));
            }
            
			// Step 4: Closing connections
            resultSet.close();
            statement.close();
            conn.close();
            
        }catch(SQLException e){
            System.err.println(e);
        }

    }
    
}
