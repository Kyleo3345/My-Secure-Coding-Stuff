/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package serverssltest;

import java.io.*;
import javax.net.ssl.*;

public class ServerSSLTest {

    public static void main(String[] args) throws IOException{
        System.setProperty("javax.net.ssl.keyStore", "C:\\Users\\angel\\Kosterman\\Server.store");
        System.setProperty("javax.net.ssl.keyStorePassword", "110354");
        System.setProperty("javax.net.debug", "ssl");

        SSLServerSocketFactory sslserversocketfactory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
        SSLServerSocket sslserversocket = (SSLServerSocket) sslserversocketfactory.createServerSocket(9999);

        SSLSocket sslSocket = (SSLSocket) sslserversocket.accept();

        BufferedReader inFromClient = new BufferedReader(new InputStreamReader(sslSocket.getInputStream()));
        BufferedWriter outToClient = new BufferedWriter(new OutputStreamWriter(sslSocket.getOutputStream()));
        String line = null;
        while ((line = inFromClient.readLine()) != null) {
            System.out.println("Received from client:" + line);
            String capitalizedSentence = line.toUpperCase();
            outToClient.write(capitalizedSentence);
            outToClient.newLine();
            outToClient.flush();
        }

        inFromClient.close();
        outToClient.close();
        sslSocket.close();
        sslserversocket.close();

    }
}
