/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package onlineauction.kyle;
import java.util.*;
/**
 *
 * @author angel
 */
public class OnlineAuctionKyle {
    
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        double a = getPriceofItem(scan);
        int b = getNumofItem(scan);
        if (!scan.hasNextDouble()) {
            System.out.println("Enter valid price!");
        } else if (!scan.hasNextInt()) {
            System.out.println("Enter valid Amount!");
        } else {
            System.out.println("You are buying " + b +
                    " items at " + a + " each");
        }
    }
    
    public static double getPriceofItem(Scanner scan) {
        System.out.print("What is the price you are willing to pay? ");
        double p = scan.nextDouble();
        return p;
    }
    
    public static int getNumofItem(Scanner scan) {
        System.out.print("How many items do you want to buy? ");
        int n = scan.nextInt();
        return n;
    }
}
