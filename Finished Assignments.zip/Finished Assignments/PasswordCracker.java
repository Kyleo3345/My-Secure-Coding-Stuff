/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package m9.assignment.kyleo;

import java.io.*;
import java.util.*;
import java.security.*;
import java.sql.*;

public class PasswordCracker {

    private final ArrayList<String> passwords;
    Connection conn;

    public PasswordCracker() throws SQLException {
        passwords = new ArrayList<>();
        String databaseURL = "jdbc:ucanaccess://c://JDBC//TestDB.accdb";
        conn = DriverManager.getConnection(databaseURL);
    }
    
    public void createTable() throws SQLException {
        
        String PasswordTableSQL = "CREATE TABLE Passwords (password TEXT(100));";
        PreparedStatement stmt1 = conn.prepareStatement(PasswordTableSQL);

        stmt1.executeUpdate();
    }

    public void loadPasswords(String filename) throws SQLException {
        try {
            File targetFile = new File(filename);
            try (Scanner scan = new Scanner(targetFile)) {
                while (scan.hasNextLine()) {
                    String password = scan.nextLine();
                    passwords.add(password);
                    addPassword(password);
                }
            }
            System.out.println("Loading Complete.");
        } catch (FileNotFoundException e) {
            System.out.println("No file found.");
        }
    }

    public String encryptPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(password.getBytes());
            byte[] digest = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            System.out.println("This Encryption Algorithm is not found.");
            return null;
        }
    }

    public boolean passwordReal(String password) throws SQLException {
        String encryptedPassword = encryptPassword(password);
        String query = "SELECT * FROM Passwords WHERE password = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, password);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            String _pwd = rs.getString("password");
            if (_pwd.equals(encryptedPassword)) {
                return true;        
            }
        }
        return false;
    }

    public void addPassword(String password) throws SQLException {
        if (!passwordReal(password)) {
            passwords.add(encryptPassword(password));
            String InsertSQL = "INSERT INTO Passwords VALUES(?);";
            PreparedStatement stmt = conn.prepareStatement(InsertSQL);
            stmt.setString(1, password);
            stmt.executeUpdate();
        } else {
            System.out.println("Password exists in Database already!");
        }
    }

    public static void main(String[] args) throws SQLException {
        PasswordCracker cracker = new PasswordCracker();
        
        cracker.createTable();
        
        try (Scanner scan = new Scanner(System.in)) {
            boolean exit = false;
            
            while (!exit) {
                System.out.println("Password Cracker System:");
                System.out.println("1) Load Passwords to DB");
                System.out.println("2) Crack Password");
                System.out.println("3) Exit");
                System.out.print("Choice: ");
                int choice = scan.nextInt();
                
                switch (choice) {
                    case 1 -> {
                        System.out.println("Enter File Name: ");
                        String filename = scan.next();
                        cracker.loadPasswords(filename);
                    }
                    case 2 -> {
                        System.out.println("Enter password attempt: ");
                        String attempt = scan.next();
                        if (cracker.passwordReal(attempt)) {
                            System.out.println("Password Exists!");
                        } else {
                            System.out.println("No password found");
                        }
                    }
                    case 3 -> exit = true;
                    default -> {
                        System.out.println("Choice invalid.");
                        System.out.println("Enter valid choice.");
                    }
                }
            }
        }
    }
}
